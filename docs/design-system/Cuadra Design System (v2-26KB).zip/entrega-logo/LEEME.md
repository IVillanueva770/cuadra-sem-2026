# Logo de Cuadra — versión actualizada (auto recentrado)

Reemplazá los archivos de logo del design system por estos. El cambio: el **auto quedó centrado verticalmente** dentro del cartel azul (antes estaba ~3px bajo). El concepto es el mismo: cartel azul de estacionamiento con un auto minimalista «estacionado».

## Archivos y dónde van

| Archivo nuevo | Reemplaza a (en el skill) | Uso |
|---|---|---|
| `cuadra-symbol.svg` | `assets/cuadra-symbol.svg` | Símbolo solo (sin texto) |
| `cuadra-logo-color.svg` | `assets/cuadra-logo-color.svg` | Lockup sobre fondo claro (texto tinta) |
| `cuadra-logo-light.svg` | `assets/cuadra-logo-light.svg` | Lockup sobre fondo oscuro/azul (texto blanco) |
| `cuadra-logo-mono.svg` | `assets/cuadra-logo-mono.svg` | Monocromo (usa `currentColor`) |
| `cuadra-icon-192.png` | `assets/cuadra-icon-192.png` | Ícono PWA 192px |
| `cuadra-icon-512.png` | `assets/cuadra-icon-512.png` | Ícono PWA 512px |
| `splash.html` | `logo-explorations/splash.html` | Animación de apertura (referencia) |

## Notas
- Las rutas que ya usan los UI kits y headers **no cambian** — son los mismos nombres de archivo, solo se actualiza el contenido.
- El `splash.html` es la animación de splash: el cartel se dibuja → el auto se estaciona → aparece «Cuadra». El auto también quedó recentrado acá.
- Si tu app ya tiene un `manifest.json` apuntando a los íconos PWA, no hay que tocar nada: mismos nombres, mismas medidas (192 y 512).
